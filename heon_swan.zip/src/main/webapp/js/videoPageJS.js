//화면 open시 로드될 데이터
$(document).ready(function(){
	$("#movie-Contents").load("./movie/basic_Contents.html");
	$("#tv-Contents").load("./tv_Program/basic_Contents.html");
	addBanner();
	
	
})


//화면 open시 화면 사이즈에 따라 로드될 배너 개수
function addBanner(){
	if($(window).width() < 900){
		
	//상단 버튼 생성	
	$('.head-category').clone().appendTo(".headcategory-copy");	
		
	var bannerSlideDiv1=$('<div>');
	bannerSlideDiv1.addClass('banneritemDiv');
	bannerSlideDiv1.css({"width" : "100%"});
	
	//bannerSlideDiv1 내 태그
	var bannerTitleDiv1=$('<div>');
	bannerTitleDiv1.css({"align-items": "left"})
	var bannerTitleLine1_1=$('<h4>');
	bannerTitleLine1_1.text("스테디셀러");
	var bannerTitleLine2_1=$('<h3>');
	bannerTitleLine2_1.text("왓챠 최고 인기작");
	var bannerTitleLine3_1=$('<h5>');
	bannerTitleLine3_1.text("뭘 볼지 모르겠다면 여기서 골라보세요!");
	bannerTitleDiv1.append(bannerTitleLine1_1).append(bannerTitleLine2_1).append(bannerTitleLine3_1);

	
	var bannerLink1=$('<a>');
	var bannerImg1=$('<img>',{
							'src':"http://localhost:8080/swan/img/cafe.jpg",
							'alt':"cafe"
	});
	bannerLink1.append(bannerImg1);
	
	
	//bannerItem에 데이터 추가
	bannerSlideDiv1.append(bannerTitleDiv1).append(bannerLink1);
	$(".banneritem").append(bannerSlideDiv1);
	
	
	
	}else if($(window).width() < 1500){
	//slide1번
	var bannerSlideDiv1=$('<div>');
	bannerSlideDiv1.addClass('banneritemDiv');
	bannerSlideDiv1.css({"width" : "50%"});
	
	//bannerSlideDiv1 내 태그
	var bannerTitleDiv1=$('<div>');
	bannerTitleDiv1.css({"align-items": "left"})
	var bannerTitleLine1_1=$('<h4>');
	bannerTitleLine1_1.text("스테디셀러");
	var bannerTitleLine2_1=$('<h3>');
	bannerTitleLine2_1.text("왓챠 최고 인기작");
	var bannerTitleLine3_1=$('<h5>');
	bannerTitleLine3_1.text("뭘 볼지 모르겠다면 여기서 골라보세요!");
	bannerTitleDiv1.append(bannerTitleLine1_1).append(bannerTitleLine2_1).append(bannerTitleLine3_1);

	
	var bannerLink1=$('<a>');
	var bannerImg1=$('<img>',{
							'src':"http://localhost:8080/swan/img/cafe.jpg",
							'alt':"cafe"
	});
	bannerLink1.append(bannerImg1);
	
	
	//slide2번
	var bannerSlideDiv2=$('<div>');
	bannerSlideDiv2.addClass('banneritemDiv');
	bannerSlideDiv2.css({"width" : "50%"});
	
	//bannerSlideDiv2 내 태그
	var bannerTitleDiv2=$('<div>');
	bannerTitleDiv2.css({"align-items": "left"})
	var bannerTitleLine1_2=$('<h4>');
	bannerTitleLine1_2.text("베스트 셀렉션");
	var bannerTitleLine2_2=$('<h3>');
	bannerTitleLine2_2.text("오직 왓챠에서!");
	var bannerTitleLine3_2=$('<h5>');
	bannerTitleLine3_2.text("왓챠 독점 오리지널 & 익스클루시브 콘텐츠");
	bannerTitleDiv2.append(bannerTitleLine1_2).append(bannerTitleLine2_2).append(bannerTitleLine3_2);

	
	var bannerLink2=$('<a>');
	var bannerImg2=$('<img>',{
							'src':"http://localhost:8080/swan/img/chair.jpg",
							'alt':"cafe"
	});
	bannerLink2.append(bannerImg2);
	
	
	//bannerItem에 데이터 추가
	bannerSlideDiv1.append(bannerTitleDiv1).append(bannerLink1);
	bannerSlideDiv2.append(bannerTitleDiv2).append(bannerLink2);
	$(".banneritem").append(bannerSlideDiv1).append(bannerSlideDiv2);
	
	
	
	
	}else{
	//slide1번
	var bannerSlideDiv1=$('<div>');
	bannerSlideDiv1.addClass('banneritemDiv');
	bannerSlideDiv1.css({"width" : "33%"});
	
	//bannerSlideDiv1 내 태그
	var bannerTitleDiv1=$('<div>');
	bannerTitleDiv1.css({"align-items": "left"})
	var bannerTitleLine1_1=$('<h3>');
	bannerTitleLine1_1.text("스테디셀러");
	var bannerTitleLine2_1=$('<h2>');
	bannerTitleLine2_1.text("왓챠 최고 인기작");
	var bannerTitleLine3_1=$('<h4>');
	bannerTitleLine3_1.text("뭘 볼지 모르겠다면 여기서 골라보세요!");
	bannerTitleDiv1.append(bannerTitleLine1_1).append(bannerTitleLine2_1).append(bannerTitleLine3_1);

	
	var bannerLink1=$('<a>');
	var bannerImg1=$('<img>',{
							'src':"http://localhost:8080/swan/img/cafe.jpg",
							'alt':"cafe"
	});
	bannerLink1.append(bannerImg1);
	
	
	//slide2번
	var bannerSlideDiv2=$('<div>');
	bannerSlideDiv2.addClass('banneritemDiv');
	bannerSlideDiv2.css({"width" : "33%"});
	
	//bannerSlideDiv2 내 태그
	var bannerTitleDiv2=$('<div>');
	bannerTitleDiv2.css({"align-items": "left"})
	var bannerTitleLine1_2=$('<h3>');
	bannerTitleLine1_2.text("베스트 셀렉션");
	var bannerTitleLine2_2=$('<h2>');
	bannerTitleLine2_2.text("오직 왓챠에서!");
	var bannerTitleLine3_2=$('<h4>');
	bannerTitleLine3_2.text("왓챠 독점 오리지널 & 익스클루시브 콘텐츠");
	bannerTitleDiv2.append(bannerTitleLine1_2).append(bannerTitleLine2_2).append(bannerTitleLine3_2);

	
	var bannerLink2=$('<a>');
	var bannerImg2=$('<img>',{
							'src':"http://localhost:8080/swan/img/chair.jpg",
							'alt':"cafe"
	});
	bannerLink2.append(bannerImg2);
	
	
	//slide3번
	var bannerSlideDiv3=$('<div>');
	bannerSlideDiv3.addClass('banneritemDiv');
	bannerSlideDiv3.css({"width" : "33%"});
	
	//bannerSlideDiv3 내 태그
	var bannerTitleDiv3=$('<div>');
	bannerTitleDiv3.css({"align-items": "left"})
	var bannerTitleLine1_3=$('<h3>');
	bannerTitleLine1_3.text("TOP 100");
	var bannerTitleLine2_3=$('<h2>');
	bannerTitleLine2_3.text("수험생들이 가장 참았던 콘텐츠는?");
	var bannerTitleLine3_3=$('<h4>');
	bannerTitleLine3_3.text("올해 가장 많이 1위를 차지한 영화 & 시리즈");
	bannerTitleDiv3.append(bannerTitleLine1_3).append(bannerTitleLine2_3).append(bannerTitleLine3_3);

	
	var bannerLink3=$('<a>');
	var bannerImg3=$('<img>',{
							'src':"http://localhost:8080/swan/img/table.jpg",
							'alt':"table"
	});
	bannerLink3.append(bannerImg3);
	
	//bannerItem에 데이터 추가
	bannerSlideDiv1.append(bannerTitleDiv1).append(bannerLink1);
	bannerSlideDiv2.append(bannerTitleDiv2).append(bannerLink2);
	bannerSlideDiv3.append(bannerTitleDiv3).append(bannerLink3);
	$(".banneritem").append(bannerSlideDiv1).append(bannerSlideDiv2).append(bannerSlideDiv3);
	
	}
}


//사이즈에 따른 배너 갯수 조절	
$(window).resize(function(){
		//상단 버튼 삭제
		$(".headcategory-copy").empty();
		
		//배너 개수 설정	
		$(".banneritemDiv").remove();
		
		addBanner();
		setTopTen_SlideNum();
		addTopTenSlide();
		
})


//카테고리 구분 버튼(전체, 영화, TV프로그램)
$(function(){
	$('.head-category > button:eq(0)').click(function(){
		$('.head-category > button').not(this).removeClass("category");
		$(this).addClass("category"); 	
		$("#movie-Contents").load("./movie/basic_Contents.html");
		$("#tv-Contents").load("./tv_Program/basic_Contents.html");
	})
	$('.head-category > button:eq(1)').click(function(){
		$('.head-category > button').not(this).removeClass("category");
		$(this).addClass("category"); 	
		$("#movie-Contents").load("./movie/category_Contents.html");
		$("#tv-Contents").load("empty.html");
	})
	$('.head-category > button:eq(2)').click(function(){
		$('.head-category > button').not(this).removeClass("category");
		$(this).addClass("category"); 	
		$("#movie-Contents").load("empty.html");
		$("#tv-Contents").load("./tv_Program/category_Contents.html");
	})
})


//topTen슬라이드 추가
function addTopTenSlide(){
	
	
	$(".topTen_slidelist").remove();
	
	var image =[];
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/cfWLI51EKgCdLkM89wNX1w.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qWTFNVEk1TlRVM09UUXdOelk1TnpVMkluMC5sY0N5RXI1elhHQi12RnVuQXlNVjlxRXB5Qk0wcDhVXzFCMmJrZmZqWjJv',
				'alt':'top1'		
	})
	)
	
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/yKtqMeCsuKXDOZhXJNp1sA.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qWTRNVFUzTkRReU1EVXlOakU1T1RRMEluMC51NXRKOTA1Y0MtTE93QzFySlFPRXpaQUJReFdHZFVBTWdEUEZlRko2emxr',
				'alt':'top2'		
	})
	)
	
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/M9HpmW9R6pEAr-lIh77n4A.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qTXhNREUwTkRjNE16VTVOREUyTnpnMkluMC5NOXk1dXJlV1JpSEpVRlBuc204REltYW1TZURmNnBleVpNcHVudDNpT1Aw',
				'alt':'top3'		
	})
	)
	
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/vah6nKsEC9zwAZ7GQpVrbw.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qUTVPVGcyTkRFM05ETTJNRGd6TkRJMUluMC5SWlRJNEJUZXVBTWpiZG4tbHhoNUE2eFZlZU90TEpMM1kzb1ByaHAtVWtJ',
				'alt':'top4'		
	})
	)
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/SdBKhTpdydb3VphmhAotIA.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qTTRNelEzT1RnNU1UTTVOVEF4TVRrM0luMC5XVDZQa3AzU0VPSmZSdXpST0FXZkFvWDNRX2tUb2IwZEhjWVIyUzhOQjQ0',
				'alt':'top5'		
	})
	)
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/fHTDXfJrd_OulnpxVBXRCg.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qWTJOemMwTlRneU16azNNREV5TWpNNUluMC5QQWdPYnBsNmtabU1WcHZFMUR0VWpUdC0tQ0c4eXFXT0VzNGJmLXdCUDFJ',
				'alt':'top6'		
	})
	)
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/VD4FUROE8xEafLgjEPu17Q.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qTXhNek16TVRFMk5qTTBOek01TVRnekluMC5VS2VUeUh0R3NTNkRCU29wdVVXb0ZGLVBUUVRQTXIxLWtsWC0yZnEyQlVF',
				'alt':'top7'		
	})
	)
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/zZJwDOb2-nmi4rGCE8Z9QA.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qWTRNVFEwTnpjNE5qQXdPRFU0TXpJd0luMC4yT0hNSjczbUF5c2t6UUh0YmNSYVNMalVpejFUOFhwandrMjhBQjlyUnVj',
				'alt':'top8'		
	})
	)
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/M9HpmW9R6pEAr-lIh77n4A.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qTXhNREUwTkRjNE16VTVOREUyTnpnMkluMC5NOXk1dXJlV1JpSEpVRlBuc204REltYW1TZURmNnBleVpNcHVudDNpT1Aw',
				'alt':'top9'		
	})
	)
	image.push($('<img>',{
				'src':'https://an2-img.amz.wtchn.net/image/v2/zeBVQVcInd1-dt31RYDJEg.jpg?jwt=ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKdmNIUnpJanBiSW1SZk56STVlREV3T0RCeE9EQWlYU3dpY0NJNklpOTJNaTl6ZEc5eVpTOXBiV0ZuWlM4eE5qWTFPVGM1TmpVMU1qRTFOVFl4TnpJeEluMC5Fd3hpdXlaaEw4bkgySVV4empCMnlkalFFa05KMHlDTDdtMUpSX0FCcl9j',
				'alt':'top10'		
	})
	)
	
	if($(window).width() < 1300){
	
	var ul = $('<ul>')
	ul.addClass('topTen_slidelist');
	
	for(k=1;k<4;k++){
		var topTen_slideitem = $('<li>');
		topTen_slideitem.addClass("topTen_slideitem");
		var topTen_slideDiv_arr=[]; 
		
		for(i=0;i<4;i++){
			var topTen_slideDiv = $('<div>');
			var topTen_a = $('<a>');
			var topTen_Rank = $('<div>');
			
			if((i+(k*4-3))<=10){
			topTen_Rank.addClass("topTen_Rank");
			topTen_Rank.text(i+(k*4-3));
			topTen_a.append(topTen_Rank).append(image[i+(k*4-4)]);
			
			
			topTen_slideDiv.append(topTen_a);
			topTen_slideDiv.addClass("topTen_slideDiv");
			topTen_slideDiv.css("width","25%");
			topTen_slideDiv_arr.push(topTen_slideDiv);
			}
	}
		
	for(i=0;i<4;i++){
		topTen_slideitem.append(topTen_slideDiv_arr[i]);
	}
	
	ul.append(topTen_slideitem);
	
	}
	$('.topTen_slidebox').append(ul);
	$('#topTen_slide03:checked','.topTen_slidelist .topTen_slideitem').css(
		"left","-150%"
	)
	
	var theme=document.querySelector(':root');
	theme.style.setProperty('--size','-150%');       
	
	}else if($(window).width() < 1900){
	
	var ul = $('<ul>')
	ul.addClass('topTen_slidelist');
	
	for(k=1;k<3;k++){
		var topTen_slideitem = $('<li>');
		topTen_slideitem.addClass("topTen_slideitem");
		var topTen_slideDiv_arr=[]; 
	
	for(i=0;i<5;i++){
		var topTen_slideDiv = $('<div>');
		var topTen_a = $('<a>');
		var topTen_Rank = $('<div>');
		
		topTen_Rank.addClass("topTen_Rank");
		topTen_Rank.text(i+(k*5-4));
		topTen_a.append(topTen_Rank).append(image[i+(k*5-5)]);
		topTen_slideDiv.append(topTen_a);
		topTen_slideDiv.addClass("topTen_slideDiv");
		topTen_slideDiv_arr.push(topTen_slideDiv);
	}
		
	for(i=0;i<5;i++){
		topTen_slideitem.append(topTen_slideDiv_arr[i]);
	}
	
	ul.append(topTen_slideitem);
	}
	$('.topTen_slidebox').append(ul);
	var theme=document.querySelector(':root');
	theme.style.setProperty('--size2','-100%');  
	
	}else{
	
	var ul = $('<ul>')
	ul.addClass('topTen_slidelist');
	
	for(k=1;k<3;k++){
		var topTen_slideitem = $('<li>');
		topTen_slideitem.addClass("topTen_slideitem");
		var topTen_slideDiv_arr=[]; 
	
	for(i=0;i<7;i++){
		var topTen_slideDiv = $('<div>');
		var topTen_a = $('<a>');
		var topTen_Rank = $('<div>');
		if((i+(k*7-6))<=10){
		topTen_Rank.addClass("topTen_Rank");
		topTen_Rank.text(i+(k*7-6));
		topTen_a.append(topTen_Rank).append(image[i+(k*7-7)]);
		topTen_slideDiv.append(topTen_a);
		topTen_slideDiv.addClass("topTen_slideDiv");
		topTen_slideDiv.css("width","14%");
		topTen_slideDiv_arr.push(topTen_slideDiv);
		}
	}
		
	for(i=0;i<7;i++){
		topTen_slideitem.append(topTen_slideDiv_arr[i]);
	}
	
	ul.append(topTen_slideitem);
	}
	$('.topTen_slidebox').append(ul);
	
	
	var theme=document.querySelector(':root');
	theme.style.setProperty('--size2','-42%');  
	}

}

//topTen 슬라이드 개수 조절
function setTopTen_SlideNum(){
	$("[id^='topTen_slide0']").remove();
	$('.topTen_slide-control').remove();
	
	
	if($(window).width() < 1300){
		for(i=0;i<3;i++){
		//input태그 생성
		var input_radio = $('<input>');
		input_radio.attr({
					'type':'radio',
					'name':'topTen_slide',
					'id':'topTen_slide0'+(i+1)
		})
	
		$('.topTen_slidebox').append(input_radio);
	}
	$('#topTen_slide01').attr('checked',true);
	
	
	var control = $('<div>');
	control.addClass("topTen_slide-control");
	
	for(i=0;i<3;i++){
		//label생성
		var control_div = $('<div>');
		var label_prev = $('<label>');
		label_prev.addClass("prev");
		var label_next = $('<label>');
		label_next.addClass("next");
		control_div.addClass("control0"+(i+1));
		
		if(i==0){
			label_prev.attr('for','topTen_slide0'+3);
		}else{
			label_prev.attr('for','topTen_slide0'+(i));
		}
		
		if(i==2){
			label_next.attr('for','topTen_slide0'+1);
		}else{
			label_next.attr('for','topTen_slide0'+(i+2));
		}
		
		
		
		
		control_div.append(label_prev).append(label_next);
		
		
		control.append(control_div);
		$('.topTen_slidebox').append(control);
	}//for
		
	}else{
	
	for(i=0;i<2;i++){
		//input태그 생성
		var input_radio = $('<input>');
		input_radio.attr({
					'type':'radio',
					'name':'topTen_slide',
					'id':'topTen_slide0'+(i+1)
		})
	
		$('.topTen_slidebox').append(input_radio);
	}
	$('#topTen_slide01').attr('checked',true);
	
	
	var control = $('<div>');
	control.addClass("topTen_slide-control");
	
	for(i=0;i<2;i++){
		//label생성
		var control_div = $('<div>');
		var label_prev = $('<label>');
		label_prev.addClass("prev");
		var label_next = $('<label>');
		label_next.addClass("next");
		control_div.addClass("control0"+(i+1));
		
		
		
		label_prev.attr('for','topTen_slide0'+(2-i));
		label_next.attr('for','topTen_slide0'+(2-i));
		control_div.append(label_prev).append(label_next);
		
		
		control.append(control_div);
		$('.topTen_slidebox').append(control);
	}//for
	
	}//1500마감


	

}
